import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirmcheckin',
  templateUrl: './confirmcheckin.component.html',
  styleUrls: ['./confirmcheckin.component.css']
})
export class ConfirmcheckinComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
