package com.bharath.flightcheckin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class FlightcheckinApplicationTests {

	@Test
	public void contextLoads() {
	}

}
