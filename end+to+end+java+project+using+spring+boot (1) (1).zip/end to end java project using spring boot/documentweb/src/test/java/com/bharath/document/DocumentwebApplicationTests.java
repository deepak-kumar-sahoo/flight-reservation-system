package com.bharath.document;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class DocumentwebApplicationTests {

	@Test
	public void contextLoads() {
	}

}
