package com.bharath.document;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DocumentwebApplication {

	public static void main(String[] args) {
		SpringApplication.run(DocumentwebApplication.class, args);
	}
}
