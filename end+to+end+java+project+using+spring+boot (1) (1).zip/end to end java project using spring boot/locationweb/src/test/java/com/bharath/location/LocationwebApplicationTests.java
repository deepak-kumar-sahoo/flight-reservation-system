package com.bharath.location;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class LocationwebApplicationTests {

	@Test
	public void contextLoads() {
	}

}
